package com.firozmemon.g_user.api;

import com.firozmemon.g_user.model.UserData;

import io.reactivex.Single;



public interface ApiRepository {

    Single<UserData> getSpecificUser(String username);

}
