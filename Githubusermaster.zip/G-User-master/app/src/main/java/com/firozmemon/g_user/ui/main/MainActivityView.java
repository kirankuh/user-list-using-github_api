package com.firozmemon.g_user.ui.main;



public interface MainActivityView {

    void displaySuccess(Object obj);

    void displayError(String message);
}
